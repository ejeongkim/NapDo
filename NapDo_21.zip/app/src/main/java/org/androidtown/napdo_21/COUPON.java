package org.androidtown.napdo_21;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class COUPON extends Fragment implements CouponAdapter.ListBtnClickListener, CouponAlertDialog.CouponAlertDialogListener {

    private ArrayList<CouponItem> couponList = new ArrayList<CouponItem>();
    private ListView coupon_listView;
    private CouponAdapter adapter;
    private Context mContext;
    private ImageView couponEmpty;
    //private LocalDatabase database;

    public COUPON() { }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_coupon, container, false);
        mContext = MainActivity.mContext;

        // 사용가능한 쿠폰이 없을 시의 이미지 참조객체 선언 및 바인딩
        couponEmpty = (ImageView)rootView.findViewById(R.id.couponEmpty);

        //database = new LocalDatabase(getApplicationContext(), "Coupon.db", null, 1); // Database open
        loadCouponItemsFromDB(); // ArrayList<couponItem>에 저장된 couponItem 로드

        adapter = new CouponAdapter(mContext, R.layout.couponitem_layout, couponList, this); // couponButtonAdapter 생성

        // ListView 참조 및 Adapter 적용하기
        coupon_listView = (ListView)rootView.findViewById(R.id.coupon_listView);
        coupon_listView.setAdapter(adapter);

        // 위에서 생성한 coupon_listView에 클릭 이벤트 핸들러 정의.
        coupon_listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // TODO : item click
            }
        });
        return rootView;
    } // onCreateView

    @Override
    public void onListBtnClick(int position) {
        /* "사용하기"버튼을 눌렀을때
         * couponButtonAdapter에서 onClick을 통하여 호출한 onListBtnClick을 구현 */
        Toast.makeText(mContext, Integer.toString(position + 1) + "번 아이템이 선택되었습니다.", Toast.LENGTH_SHORT).show();

        // 사용자가 사용하기위해 선택한 coupon의 couponName을 가져옴
        CouponItem delCoupon = couponList.get(position);

        // Custom DialogFragment 객체 생성 및 호출
        CouponAlertDialog couponAlertDialog = new CouponAlertDialog();
        showAlertDialog();
    }

    public void showAlertDialog() {
        /* Custom DialogFragment를 호출 */
        android.support.v4.app.FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        CouponAlertDialog couponAlertDialog = new CouponAlertDialog();
        couponAlertDialog.setTargetFragment(COUPON.this, 300);
        couponAlertDialog.show(fragmentManager, "Coupon Use");
    } // showAlertDialog()

    @Override
    public void onCouponDialog(boolean state) {
        /* 사용자가 AlertDialog에서 누른 버튼에 따른 반응 */

        if(state) // "사용" 눌렀을 때. 여기에다가 사용 시에 데이터 지워지는 코드 삽입
            Toast.makeText(mContext, "사용 누름", Toast.LENGTH_SHORT).show();
        else // "취소" 눌렀을 때. 여기에다가 취소 시의 코드 삽입. 아무것도 안할거면 그냥 if만 해도 될듯!
            Toast.makeText(mContext, "취소 누름", Toast.LENGTH_SHORT).show();
    }

    public void loadCouponItemsFromDB() {
        /* LocalDatabase로부터 Data를 읽어들이는 함수 */

        // 기존의 couponList를 초기화한 후에 데이터를 로드한다.
        // ListView의 갱신 문제로 인해 이런 방식을 사용
        //couponList.clear();
        //database.getData(couponList);

        CouponItem couponItem = new CouponItem("2016년 11월 24일", "2016년 12월 24일");
        couponList.add(couponItem);
        couponList.add(couponItem);

        // 읽어들인 Data의 수에 따라 EmptyImageView 참조 및 visibility 조정
        if(couponList.isEmpty()) {
            // couponList에 등록된 coupon이 없으면 empty Image를 보여줌
            couponEmpty.setImageResource(R.mipmap.ic_launcher);
            couponEmpty.setVisibility(View.VISIBLE);
        }
    } // loadCouponItemsFromDB

} // COUPON
