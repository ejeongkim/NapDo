package org.androidtown.napdo_21;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by Hyun on 2016-11-29.
 * 참고사이트 http://www.androidinterview.com/android-custom-dialog-box-example-android-dialog/
 */

public class CouponAlertDialog extends DialogFragment {

    private Button couponAlert_use, couponAlert_cancel;
    private boolean state;

    public CouponAlertDialog(){ }

    // Button event를 받는 객체에서 구현할 Listener interface
    public interface CouponAlertDialogListener { void onCouponDialog(boolean state); }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
        View dialogView= inflater.inflate(R.layout.coupon_alertdialog, container);

        // Dialog 내의 Button 참조객체 선언 및 바인딩
        couponAlert_use = (Button) dialogView.findViewById(R.id.couponAlert_use);
        couponAlert_cancel = (Button) dialogView.findViewById(R.id.couponAlert_cancel);

        // 각 Button에 listener 등록
        couponAlert_use.setOnClickListener(couponAlertListener);
        couponAlert_cancel.setOnClickListener(couponAlertListener);

        return dialogView;
    } // onCreateView()


    // dialog에서 button의 event를 받아 그 결과를 parent fragment에 넘기기위한 listener 구현
    private View.OnClickListener couponAlertListener = new View.OnClickListener() {
        public void onClick(View view) {
            /* alertDialog에 있는 버튼을 눌렀을 때, 어떤 버튼이 눌렸는지 반환 */
            CouponAlertDialogListener targetFragment =  (CouponAlertDialogListener) getTargetFragment(); // 결과를 받을 TargetFragment 선언

            // 사용자가 누른 버튼에 따라 state를 전환
            switch(view.getId()) {
                case R.id.couponAlert_use: // "사용"버튼을 눌렀을 때
                    state = true;
                    break;
                case R.id.couponAlert_cancel: // "취소"버튼을 눌렀을 때
                    state = false;
                    break;
            }

            targetFragment.onCouponDialog(state); // COUPON class에서 구현된 onCouponDialog를 호출한다.
            dismiss();

        } // onClick()

    }; // View.OnClickListener()

} // CouponAlertDialog
