package org.androidtown.napdo_21;

import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by ejeong on 2016-11-08.
 */
// HOME 화면 Activity
public class HOME extends Fragment {

    // HOME Fragment를 가지고 있는 Activity
    // HomeResult Fragment를 전역변수로 설정
    public static Fragment mFragmentHomeResult;
    int REQUEST_CODE = 1; //LocationInputActivity로 갔다가 다시 HOME으로 돌아 올 때 사용

    Button mBtnStart;
    Button mBtnDesti;

    SensorManager mSensorMgr = null;
    AudioManager mAudioManager;


    Boolean isInput = false;

    // onCraet() 다음에 호출되는 함수를 overriding
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        return v;
    }


}

//
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == REQUEST_CODE) {
//            if (resultCode == RESULT_OK) {
//                //btn_des.setSelected("true");
//
//            }
//
//        }
//    }
